# YuNet H13 linked candidate

This source-built package contains the same MIT YuNet 2023mar learned weights
as the audited CPU export, plus procedural layout/max-tree coefficients. It
contains one ANEC program with 113 tasks and no host graph partitions.

The input boundary converts BGR 320x320 to a phase layout. The output boundary
decodes 48 useful head channels from a 64-channel tensor, including score
sigmoid. Those operations run outside the program and are included in device
frame timing. The package uses 34,324,480 bytes of scratch.

Host decoded-DRAM dataflow simulation with package-MIL arithmetic passes the original tensor gate on all 30 audited
portraits. host-parity.json is a CPU simulation receipt. Its timings are not
ANE timings and it cannot authorize production loading. No device
qualification.json is supplied. Until the lead's controller-approved M1 Pro
qualification passes parity, speed and wedged checks, the model uses CPU.

Use the paired feature branches of mil-hwx-compiler and omarchy-ane. Install
these files in MODEL_ROOT/yunet/compiled/H13/linked, preserving any previous
package before replacement. Retain the original checked YuNet CPU export in
MODEL_ROOT/yunet. From examples/camera-effects run the documented one-command
linked/qualify.py with --model yunet inside the approved controller request.

Model licence: LICENSE-MODEL. Compiler licence: LICENSE-COMPILER. Evaluation
images are not included; see EVALUATION-SOURCES.json and LICENCE-AUDIT.md in
the effects source. No ANE speedup or device parity result is claimed here.
